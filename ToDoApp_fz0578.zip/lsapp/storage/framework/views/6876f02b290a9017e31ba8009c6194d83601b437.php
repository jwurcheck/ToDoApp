<?php $__env->startSection('content'); ?>
<div class="panel-body">
        <form action="/items" method="POST" class="form-horizontal">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <label for="item" class="col-sm-2 control-label">Item</label>
                <div class="col-sm-5">
                    <input type="text" name="name" id="item-name" class="form-control">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-5">
                    <button type="submit" class="btn btn-default"><i class="fa fa-plus"></i>Add Item</button>
                </div>
            </div>
        </form>
    </div>
    <br><br><br>
    <?php if(count($items) > 0): ?>
        <div class="panel panel-default">
            <div class="panel-heading">To Do Items</div>
            <div class="panel-body">
                <table class="table table-striped item-table">
                    <thead>
                        <th>Item</th>
                        <th>&nbsp;</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="table-text">
                                    <div><?php echo e($item->name); ?></div>
                                </td>

                                <td>
                                    <form action="/items/<?php echo e($item->id); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button>Delete</button>
                                        <input type="hidden" name="_method" value="DELETE">
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/items.blade.php ENDPATH**/ ?>