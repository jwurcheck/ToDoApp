@extends('layouts.app')
@section('content')
<div class="panel-body">
        <form action="/items" method="POST" class="form-horizontal">
            {{csrf_field()}}

            <div class="form-group">
                <label for="item" class="col-sm-2 control-label">Item</label>
                <div class="col-sm-5">
                    <input type="text" name="name" id="item-name" class="form-control">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-5">
                    <button type="submit" class="btn btn-default"><i class="fa fa-plus"></i>Add Item</button>
                </div>
            </div>
        </form>
    </div>
    <br><br><br>
    @if(count($items) > 0)
        <div class="panel panel-default">
            <div class="panel-heading">To Do Items</div>
            <div class="panel-body">
                <table class="table table-striped item-table">
                    <thead>
                        <th>Item</th>
                        <th>&nbsp;</th>
                    </thead>
                    <tbody>
                        @foreach($items as $item)
                            <tr>
                                <td class="table-text">
                                    <div>{{$item->name}}</div>
                                </td>

                                <td>
                                    <form action="/items/{{$item->id}}" method="POST">
                                        {{csrf_field()}}
                                        {{method_field('DELETE')}}
                                        <button>Delete</button>
                                        <input type="hidden" name="_method" value="DELETE">
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @endif

@endsection