<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Laravel Quickstart - Basic</title>
    </head>

    <body>
        <div class="container">
            <nav class="navbar navbar-default">
            </nav>
        </div>

        @yield('content')
    </body>
</html>